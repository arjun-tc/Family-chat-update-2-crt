import { Injectable } from '@angular/core';
import { Subject, config } from 'rxjs';
@Injectable({
   providedIn: 'root'
})
export class InteractionService {
   private _MessageSource = new Subject<string>();
   private _senderNameSource = new Subject<string>();
   private _receiverNameSource = new Subject<string>();
   private _replyMessageSource = new Subject<string>();
   replyMessage$ = this._replyMessageSource.asObservable();
   Message$ = this._MessageSource.asObservable();
   senderName$ = this._senderNameSource.asObservable();
   receiverName$ = this._receiverNameSource.asObservable();
   listOfNames = [];
   indexOfReceiver: number;
   indexOfSender: number;
   reply = "";
   chat = [];

   people = [{
      "name": "James", "Ques": { "what is your Name": "James", "How Old are you": 89 }, "About": "ParentData"
   },
   {
      "name": "Adithya", "Ques": { "what is your Name": "Adithya", "How Old are you": 45 }, "About": "Child1Data"
   },
   {
      "name": "Dilip", "Ques": { "what is your Name": "Dilip", "How Old are you": 43 }, "About": "Child2Data"
   },
   {
      "name": "Stephen", "Ques": { "what is your Name": "Stephen", "How Old are you": 35 }, "About": "Child3Data"
   },
   {
      "name": "Groot", "Ques": { "what is your Name": "Groot", "How Old are you": 23 }, "About": "SonOfAdithya"
   },
   {
      "name": "Thor", "Ques": { "what is your Name": "Thor", "How Old are you": 20 }, "About": "SonOfDilip"
   }
   ];
   constructor() { }
   sendMessage(receiverName: string, message: string, senderName: string) {
    
      this.setReply(receiverName, message ,senderName)
      this._replyMessageSource.next(this.reply);
      this._MessageSource.next(`${senderName}: ${message}`);
      this._senderNameSource.next(senderName);
      this._receiverNameSource.next(receiverName);
      this.chat.push(`${senderName} : @${receiverName} ${message}`);
      this.chat.push(`${this.reply}`);

   }
   setReply(receiverName: string, message: string ,senderName: string) {
      this.listOfNames = this.people.map(value => value.name);
      this.indexOfReceiver = this.listOfNames.findIndex(value => value == receiverName);
      if (Object.keys(this.people[this.indexOfReceiver].Ques).some(value => value == message)) {
         this.reply = `${receiverName}: ${this.people[this.indexOfReceiver].Ques[message]}`;
      }
      else {
         this.reply = `${receiverName}: sorry I don't get you`;
      }
   }
  
}