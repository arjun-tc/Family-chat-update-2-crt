import { Component, OnInit } from '@angular/core';
import { InteractionService } from '../../interaction.service';
@Component({
  selector: 'app-dilip',
  templateUrl: './dilip.component.html',
  styleUrls: ['./dilip.component.scss']
})
export class DilipComponent implements OnInit {

 
  constructor(private _interactionService: InteractionService) { }
  
  name = "Dilip";
  question = "there is no question";
  answer = "there is no reply";
  message ="There is no new message";
  replyMessage = "you did'nt messaged anyone";
  ngOnInit() {
    this._interactionService.Message$
      .subscribe(
        message => {
          this.question = message;
        }
      )
    this._interactionService.replyMessage$
      .subscribe(
        reply => {
          this.answer = reply;
        })
    this._interactionService.receiverName$
      .subscribe(
        receiverName => {
          if (receiverName == this.name) {
            this.getMessage();
          }
        }
      )
      this._interactionService.senderName$
     .subscribe(
      senderName =>{
           if(senderName == this.name){
             this.getReply();
           }           
         }
     ) 

  }
  getReply(){
    this.replyMessage =`Reply From ${this.answer}`;
  }
  getMessage(){
    this.message = `Message From  ${this.question}`;   
  }
}
