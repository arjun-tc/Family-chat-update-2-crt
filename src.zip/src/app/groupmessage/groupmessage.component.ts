import { Component, OnInit } from '@angular/core';
import { InteractionService } from '../interaction.service';

@Component({
  selector: 'app-groupmessage',
  templateUrl: './groupmessage.component.html',
  styleUrls: ['./groupmessage.component.scss']
})
export class GroupmessageComponent implements OnInit {

  constructor(private _interactionService: InteractionService) { }

chat = this._interactionService.chat;
  ngOnInit(): void {
  }
}
